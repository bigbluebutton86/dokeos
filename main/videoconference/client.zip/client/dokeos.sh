#!/bin/bash
########################################################
# Dokeos Video Conference Installation Script          #
# Author: Claudio Montoya (claudio.montoya@dokeos.com) #
# Date: December 2010                                  #
# Dokeos Version: 2.0                                  #
########################################################

# Delete demo files for BBB
rm -rf /var/lib/tomcat6/webapps/bigbluebutton/demo
rm /var/www/bigbluebutton-default/help.html

# Copy customized API onapplication server
cp dokeos/ApiController\$_closure3.class /var/lib/tomcat6/webapps/bigbluebutton/WEB-INF/classes/org/bigbluebutton/web/controllers/ 
cp dokeos/index.html /var/www/bigbluebutton-default/index.html
cp dokeos/favicon.ico /var/www/bigbluebutton-default/favicon.ico
