A note by the Dokeos Team

For showing flash-based multimedia the Dokeos LMS uses
the Flash Video Player 3.5 by Jeroenwijering.

Despite its name the player works with audio (mp3) files too.

Flash Video Player 3.5 has been released by Moodle (TM) - moodle.org
under the conditions of GNU GPL version 2 or later and with the permission
by Jeroen Wijering - www.jeroenwijering.com

See the included original files within source/ folder.

Additional information you may find at:
http://tracker.moodle.org/browse/MDL-19117
http://www.dokeos.com/forum/viewtopic.php?p=48486#48486
http://projects.dokeos.com/index.php?do=details&task_id=2867#comment17847

July 16-th, 2009
