SWFObject 1.5 & 2.2 hybrid solution for the Dokeos LMS 1.8.x

This copy of SWFObject script has been placed here for backward compatibility.
The permanent location of this script is dokeos/main/inc/lib/swfobject/
See there for source and licensing information.

