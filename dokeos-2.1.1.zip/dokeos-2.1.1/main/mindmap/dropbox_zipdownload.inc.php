<?php //$id: $
/* For licensing terms, see /dokeos_license.txt */

// the file that contains all the initialisation stuff (and includes all the configuration stuff)
require_once( "dropbox_init.inc.php");
?>