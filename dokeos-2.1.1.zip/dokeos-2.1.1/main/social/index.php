<?php
/* For licensing terms, see /dokeos_license.txt */

header('Location: profile.php');
exit();		
?>