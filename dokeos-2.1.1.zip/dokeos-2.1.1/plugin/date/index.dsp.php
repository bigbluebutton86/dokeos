  <?php echo strip_tags($date); ?>
